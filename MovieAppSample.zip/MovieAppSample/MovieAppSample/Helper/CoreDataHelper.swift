//
//  CoreDataHelper.swift
//  MovieAppSample
//
//  Created by Office on 25/02/25.
//
import CoreData
import UIKit

class CoreDataHelper {
    static let shared = CoreDataHelper()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    func saveContext() {
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                print("Failed to save context: \(error)")
            }
        }
    }
    
    func fetchMovies() -> [Movie] {
        let fetchRequest: NSFetchRequest<Movie> = Movie.fetchRequest()
        do {
            return try context.fetch(fetchRequest)
        } catch {
            print("Failed to fetch movies: \(error)")
            return []
        }
    }
    
    func saveMovie(title: String, overview: String, rating: String) {
        let movie = Movie(context: context)
        movie.title = title
        movie.overview = overview
        movie.rating = rating
        movie.watchLater = false
        
        saveContext()
    }
    
    func markAsWatchLater(title: String) {
        let fetchRequest: NSFetchRequest<Movie> = Movie.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "title = %@", title)
        
        do {
            if let movie = try context.fetch(fetchRequest).first {
                movie.watchLater = true
                saveContext()
            }
        } catch {
            print("Failed to mark as watch later: \(error)")
        }
    }
    
    func fetchWatchLaterMovies() -> [Movie] {
        let fetchRequest: NSFetchRequest<Movie> = Movie.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "watchLater = true")
        
        do {
            return try context.fetch(fetchRequest)
        } catch {
            print("Failed to fetch watch later movies: \(error)")
            return []
        }
    }
}

