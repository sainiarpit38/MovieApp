//
//  MovieModel.swift
//  MovieAppSample
//
//  Created by Office on 25/02/25.
//

import Foundation

//struct MovieResult: Codable {
//    let title: String
//    let overview: String
//    let releaseDate: String
//    let rating: String
//}
//
//struct MovieResponse: Codable {
//    let results: [MovieResult]
//}
//
//
//

struct MovieResult: Decodable {
    let id: Int
    let title: String
    let originalTitle: String
    let overview: String
    let releaseDate: String
    let posterPath: String?
    let voteAverage: Double
    let popularity: Double

    enum CodingKeys: String, CodingKey {
        case id, title, overview, popularity
        case originalTitle = "original_title"
        case releaseDate = "release_date"
        case posterPath = "poster_path"
        case voteAverage = "vote_average"
    }
}

struct MovieResponse: Decodable {
    let results: [MovieResult]
}
