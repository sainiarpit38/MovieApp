//
//  WatchLaterViewController.swift
//  MovieAppSample
//
//  Created by Office on 25/02/25.
//

import UIKit

class WatchLaterCell : UITableViewCell {
    @IBOutlet weak var movieBackdrop: UIImageView!
    @IBOutlet weak var movieOverview: UILabel!
    @IBOutlet weak var movieRate: UILabel!
    @IBOutlet weak var movieTitle: UILabel!
    
}


class WatchLaterViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    
    var watchLaterMovies: [Movie] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        loadWatchLaterMovies()
    }
    
    func loadWatchLaterMovies() {
        watchLaterMovies = CoreDataHelper.shared.fetchWatchLaterMovies()
        
        print("watchLaterMovies=======",watchLaterMovies)
        tableView.reloadData()
    }
    
    // MARK: - TableView Methods
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return watchLaterMovies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : WatchLaterCell! = tableView.dequeueReusableCell(withIdentifier: "WatchLaterCell") as? WatchLaterCell
        let movie = watchLaterMovies[indexPath.row]
        
        cell.movieTitle.text = movie.title
        cell.movieRate?.text = "⭐️\(String(describing: movie.rating))"
        cell.movieOverview?.text = movie.overview
        
        DispatchQueue.main.async {
            
            if movie.image == "https://image.tmdb.org/t/p/original/" {
                cell.movieBackdrop.image = UIImage(systemName: "photo.on.rectangle.angled")
            } else {
                //cell.movieBackdrop.sd_setImage(with: URL(string: data.posterPath), placeholderImage: UIImage(systemName: "photo.on.rectangle.angled"))
            }
        }
        return cell
    }
}
