//
//  MovieListViewController.swift
//  MovieAppSample
//
//  Created by Office on 25/02/25.
//

import UIKit


class MovieCell : UITableViewCell {
    @IBOutlet weak var movieBackdrop: UIImageView!
    @IBOutlet weak var movieOverview: UILabel!
    @IBOutlet weak var movieRate: UILabel!
    @IBOutlet weak var movieTitle: UILabel!
    
    @IBOutlet weak var btn_WatchListOot: UIButton!
}

class MovieListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    var searchActive = Bool()
    var filterdata : [MovieResult] = []
    
    var movies: [MovieResult] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        searchBar.delegate = self
        
        fetchMovies()
    }
    
    func fetchMovies() {
        // Fetch movies from API (e.g., TMDb API)
        let urlString = "https://api.themoviedb.org/3/movie/popular?api_key=0b4a804d04c4f3ac0d8f76ac9749d0e3"
        guard let url = URL(string: urlString) else { return }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else { return }
            do {
                let json = try JSONDecoder().decode(MovieResponse.self, from: data)
                self.movies = json.results
                print("self.movies========",self.movies)
                // Save movies to Core Data
                for movie in json.results {
                    CoreDataHelper.shared.saveMovie(title: movie.title, overview: movie.overview, rating: "\(movie.voteAverage)")
                }
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            } catch {
                print("Failed to decode JSON")
            }
        }.resume()
    }
    
    // MARK: - TableView Methods
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searchActive {
            return filterdata.count
        }
        else {
            return movies.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell : MovieCell! = tableView.dequeueReusableCell(withIdentifier: "MovieCell") as? MovieCell
        
        if searchActive {
            let movie = filterdata[indexPath.row]
            
            cell.movieTitle.text = movie.title
            cell.movieRate?.text = "⭐️\(movie.voteAverage)"
            cell.movieOverview?.text = movie.overview
            
            cell.btn_WatchListOot.tag = indexPath.row
            cell.btn_WatchListOot.addTarget(self, action: #selector(clkToWatchLater(sender:)), for: .touchUpInside)
            
            DispatchQueue.main.async {
                
                if movie.posterPath == "https://image.tmdb.org/t/p/original/" {
                    cell.movieBackdrop.image = UIImage(systemName: "photo.on.rectangle.angled")
                } else {
                    //cell.movieBackdrop.sd_setImage(with: URL(string: data.posterPath), placeholderImage: UIImage(systemName: "photo.on.rectangle.angled"))
                }
                
            }
        }
        else {
            let movie = movies[indexPath.row]
            
            cell.movieTitle.text = movie.title
            cell.movieRate?.text = "⭐️\(movie.voteAverage)"
            cell.movieOverview?.text = movie.overview
            
            cell.btn_WatchListOot.tag = indexPath.row
            cell.btn_WatchListOot.addTarget(self, action: #selector(clkToWatchLater(sender:)), for: .touchUpInside)
            
            DispatchQueue.main.async {
                
                if movie.posterPath == "https://image.tmdb.org/t/p/original/" {
                    cell.movieBackdrop.image = UIImage(systemName: "photo.on.rectangle.angled")
                } else {
                    //cell.movieBackdrop.sd_setImage(with: URL(string: data.posterPath), placeholderImage: UIImage(systemName: "photo.on.rectangle.angled"))
                }
            }
        }
        
        return cell
    }
    
    @objc func clkToWatchLater(sender: UIButton) {
        if searchActive {
            let selectedMovie = filterdata[sender.tag]
            
            // Mark as watch later
            CoreDataHelper.shared.markAsWatchLater(title: selectedMovie.title)
            
            let alert = UIAlertController(title: "Marked as Watch Later", message: "\(selectedMovie.title) has been marked as watch later.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            
            present(alert, animated: true)
        }
        else {
            
            let selectedMovie = movies[sender.tag]
            
            // Mark as watch later
            CoreDataHelper.shared.markAsWatchLater(title: selectedMovie.title)
            
            let alert = UIAlertController(title: "Marked as Watch Later", message: "\(selectedMovie.title) has been marked as watch later.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            
            present(alert, animated: true)
        }
    }
    
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let selectedMovie = movies[indexPath.row]
//        
//        // Mark as watch later
//        CoreDataHelper.shared.markAsWatchLater(title: selectedMovie.title)
//        
//        let alert = UIAlertController(title: "Marked as Watch Later", message: "\(selectedMovie.title) has been marked as watch later.", preferredStyle: .alert)
//        alert.addAction(UIAlertAction(title: "OK", style: .default))
//        
//        present(alert, animated: true)
//    }
}


//MARK: - Searchbar delegates
extension MovieListViewController: UISearchBarDelegate {
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(true, animated: true)
    }
    
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.setShowsCancelButton(false, animated: true)
        searchBar .resignFirstResponder()
        searchActive = false
        searchBar.text = ""
        self.tableView.reloadData()
    }
      
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        DispatchQueue.main.async {
            searchBar.showsCancelButton = true
            if let cancelButton = searchBar.value(forKey: "cancelButton") as? UIButton {
                cancelButton.isEnabled = true
            }
        }
    }
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.count == 0 {
            searchActive = false
            searchBar.setShowsCancelButton(true, animated: true)
        }
        else {
            searchActive = true
            filterdata.removeAll()
            for i in 0..<movies.count {
                let obj = self.movies[i]
                let item1 = obj.title
                let item2 = obj.overview
                if (item1 as NSString?)?.range(of: searchText, options: .caseInsensitive).location != NSNotFound || (item2 as NSString?)?.range(of: searchText, options: .caseInsensitive).location != NSNotFound
                {
                    filterdata.append(movies[i])
                }
            }
        }
        self.tableView.reloadData()
    }
    
}
